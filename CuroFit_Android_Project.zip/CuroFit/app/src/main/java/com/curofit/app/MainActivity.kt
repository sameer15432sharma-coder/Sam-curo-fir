package com.curofit.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

private val Green=Color(0xFF43E879); private val Dark=Color(0xFF07100B); private val Card=Color(0xFF111B15); private val Muted=Color(0xFF9AA59D)

data class Exercise(val name:String,val body:String,val level:String,val reps:String,val sets:Int,val curo:Int,val how:String,val avoid:String)
data class Outfit(val name:String,val style:String,val price:Int,val emoji:String)

class CuroVM:androidx.lifecycle.ViewModel(){
 var curo by mutableIntStateOf(1000); private set; var level by mutableIntStateOf(1); private set; var completed by mutableIntStateOf(0); private set
 var worn by mutableStateOf("Starter"); private set; var owned by mutableStateOf(setOf("Starter")); private set
 fun complete(e:Exercise){completed++;curo+=e.curo;if(completed%10==0){level++;curo+=1000}}
 fun buy(o:Outfit){if(o.name !in owned&&curo>=o.price){curo-=o.price;owned=owned+o.name}}
 fun wear(n:String){if(n in owned)worn=n}
}

val exs=listOf(
 Exercise("Push-up","Chest + Triceps","Beginner","5–10",2,5,"Keep your body aligned, lower with control and press up.","Do not rush or let your lower back sag."),
 Exercise("Bodyweight Squat","Legs + Glutes","Beginner","8–12",2,6,"Sit hips back, keep feet stable and stand smoothly.","Do not force depth or let knees collapse inward."),
 Exercise("Glute Bridge","Glutes","Beginner","8–12",2,5,"Lift hips smoothly while keeping the movement comfortable.","Do not over-arch your back."),
 Exercise("Wall Push-up","Chest + Arms","Beginner","8–12",2,4,"Use a wall and move your chest toward it with control.","Do not lock elbows hard or move too fast."),
 Exercise("Bird Dog","Core + Back","Beginner","6 each side",2,5,"Extend opposite arm and leg while keeping hips controlled.","Do not twist or hold your breath."),
 Exercise("Dead Bug","Core","Beginner","6 each side",2,5,"Move opposite limbs slowly while keeping your torso controlled.","Stop if your back becomes uncomfortable."),
 Exercise("Reverse Lunge","Legs + Glutes","Beginner","6 each side",2,7,"Step backward and lower only through a comfortable range.","Avoid unstable or painful movement."),
 Exercise("Calf Raise","Calves","Beginner","10–15",2,4,"Rise onto your toes with control and lower slowly.","Do not bounce rapidly."),
 Exercise("Incline Push-up","Chest + Triceps","Intermediate","6–12",2,8,"Use a stable elevated surface and maintain alignment.","Never use an unstable surface."),
 Exercise("Step-up","Legs + Glutes","Intermediate","6 each side",2,7,"Use a stable low step and step up under control.","Do not use a slippery or unstable step."),
 Exercise("Plank","Core","Intermediate","15–30 sec",2,6,"Keep a comfortable neutral position and breathe normally.","Do not hold your breath or force duration."),
 Exercise("Side Plank","Core + Obliques","Intermediate","10–20 sec each",2,7,"Support yourself comfortably and keep hips controlled.","Stop if shoulder or back hurts."),
 Exercise("Mountain Climber","Core + Cardio","Intermediate","15–25 sec",2,8,"Move at a controlled pace from a stable position.","Do not sacrifice control for speed."),
 Exercise("Split Squat","Legs + Glutes","Intermediate","6–10 each",2,9,"Use a comfortable stance and lower smoothly.","Do not force range of motion."),
 Exercise("Knee Push-up","Chest + Triceps","Beginner","6–12",2,5,"Keep torso aligned from knees to shoulders.","Do not let hips collapse."),
 Exercise("Shoulder Tap","Shoulders + Core","Beginner","6 each side",2,6,"Tap the opposite shoulder slowly from a stable position.","Avoid excessive hip rotation."),
 Exercise("Superman Hold","Back","Beginner","10–20 sec",2,5,"Lift gently within a comfortable range.","Do not crank your neck upward."),
 Exercise("March in Place","Full Body","Beginner","30–60 sec",2,4,"March comfortably with relaxed breathing.","Stop if dizzy or unwell.")
)
val outfits=listOf(
 Outfit("Starter","Classic",0,"🧢"),Outfit("Mumbai Street","Indian",500,"👕"),Outfit("Desi Athlete","Indian",900,"🧥"),Outfit("Kurta Sport","Indian",1200,"🥻"),Outfit("Cricket Green","Indian",1500,"🏏"),Outfit("Urban Runner","Western",700,"🏃"),Outfit("Night Gym","Western",1100,"🖤"),Outfit("Retro Track","Western",1400,"🧥"),Outfit("Street Legend","Western",1800,"🕶️"),Outfit("Royal Fusion","Indo-Western",2200,"👑"),Outfit("Neon Athlete","Western",2500,"⚡"),Outfit("Festival Sport","Indian",2800,"✨")
)

@Composable fun App(vm:CuroVM=viewModel()){
 var tab by remember{mutableIntStateOf(0)}; var selected by remember{mutableStateOf<Exercise?>(null)}
 MaterialTheme(colorScheme=darkColorScheme(primary=Green,background=Dark,surface=Card)){
  Scaffold(containerColor=Dark,bottomBar={NavigationBar(containerColor=Color(0xFF09110C)){val items=listOf("Home" to Icons.Default.Home,"Exercises" to Icons.Default.FitnessCenter,"Routine" to Icons.Default.CalendarMonth,"Avatar" to Icons.Default.Face);items.forEachIndexed{i,p->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(p.second,null)},label={Text(p.first)})}}}){pad->Column(Modifier.padding(pad)){when(tab){0->Home(vm,{tab=1},{tab=2});1->Exercises(vm){selected=it};2->Routine(vm){selected=it};3->Shop(vm)}}}
  selected?.let{ExerciseDialog(it,{selected=null}){vm.complete(it);selected=null}}
 }
}

@Composable fun Header(vm:CuroVM){Row(Modifier.fillMaxWidth().padding(20.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column{Text("CuroFit",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text("Level ${vm.level}",color=Muted)};Surface(color=Color(0xFF16261B),shape=MaterialTheme.shapes.extraLarge){Text("🪙 ${vm.curo} CURO",Modifier.padding(horizontal=14.dp,vertical=9.dp),color=Green,fontWeight=FontWeight.Bold)}}}

@Composable fun Home(vm:CuroVM,goEx:()->Unit,goRoutine:()->Unit){LazyColumn(contentPadding=PaddingValues(bottom=20.dp)){item{Header(vm)};item{Card(Modifier.padding(horizontal=20.dp).fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Card)){Column(Modifier.padding(20.dp)){Text("Your progress",fontWeight=FontWeight.Bold);Spacer(Modifier.height(10.dp));LinearProgressIndicator(progress={(vm.completed%10)/10f},Modifier.fillMaxWidth(),color=Green);Spacer(Modifier.height(8.dp));Text("${vm.completed} exercises completed",color=Muted);Text("Complete 10 exercises to reach the next level",color=Muted)}}};item{Text("Focus areas",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,Modifier.padding(20.dp))};item{LazyRow(contentPadding=PaddingValues(horizontal=20.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("Chest","Back","Legs","Core","Arms","Shoulders","Full Body").forEach{item{AssistChip(onClick=goEx,label={Text(it)})}}}};item{Card(Modifier.padding(20.dp).fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color(0xFF102719))){Column(Modifier.padding(20.dp)){Text("Optional routine",fontWeight=FontWeight.Bold);Text("You choose whether to use it.",color=Muted);Spacer(Modifier.height(10.dp));Button(onClick=goRoutine,colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Color.Black)){Text("View routine")}}}};item{Safety()}}}
@Composable fun Safety(){Card(Modifier.padding(horizontal=20.dp).fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color(0xFF211B12))){Column(Modifier.padding(18.dp)){Text("Train smart",fontWeight=FontWeight.Bold);Spacer(Modifier.height(6.dp));Text("Warm up, use controlled form, rest as needed, drink water, and stop if you feel pain, dizziness, faintness, unusual shortness of breath, or feel unwell. Rewards never require pushing through pain.",color=Color(0xFFE5D4B5))}}}

@Composable fun Exercises(vm:CuroVM,onSelect:(Exercise)->Unit){var filter by remember{mutableStateOf("All")};val parts=listOf("All","Chest","Back","Legs","Core","Arms","Shoulders","Full Body");val list=exs.filter{filter=="All"||it.body.contains(filter,true)};Column{Header(vm);LazyRow(contentPadding=PaddingValues(horizontal=20.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){parts.forEach{item{FilterChip(selected=filter==it,onClick={filter=it},label={Text(it)})}}};LazyColumn(contentPadding=PaddingValues(20.dp)){items(list){ExerciseCard(it,onSelect)}}}}
@Composable fun ExerciseCard(e:Exercise,onSelect:(Exercise)->Unit){Card(Modifier.fillMaxWidth().padding(vertical=6.dp).clickable{onSelect(e)},colors=CardDefaults.cardColors(containerColor=Card)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Surface(Modifier.size(55.dp),color=Color(0xFF18301F),shape=MaterialTheme.shapes.medium){Box(contentAlignment=Alignment.Center){Text("💪")}};Column(Modifier.weight(1f).padding(horizontal=14.dp)){Text(e.name,fontWeight=FontWeight.Bold);Text(e.body,color=Muted);Text("${e.sets} sets • ${e.reps}",color=Muted)};Text("+${e.curo}",color=Green,fontWeight=FontWeight.Bold)}}}

@Composable fun Routine(vm:CuroVM,onSelect:(Exercise)->Unit){var enabled by remember{mutableStateOf(false)};val routine=listOf(exs[3],exs[1],exs[4],exs[0],exs[7]);Column{Header(vm);Row(Modifier.fillMaxWidth().padding(20.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Optional balanced routine",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);Text("Use it only if you want to.",color=Muted)};Switch(enabled,{enabled=it})};if(enabled)LazyColumn(contentPadding=PaddingValues(20.dp)){items(routine){ExerciseCard(it,onSelect)};item{Text("Rest between sets as needed. Quality matters more than speed.",color=Muted)}}else Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text("Routine is off. Your choice.",color=Muted)}}}

@Composable fun Shop(vm:CuroVM){Column{Header(vm);Text("Avatar & outfits",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,Modifier.padding(20.dp));Text("Cosmetic items only — they do not change exercise difficulty.",color=Muted,Modifier.padding(horizontal=20.dp));LazyColumn(contentPadding=PaddingValues(20.dp)){items(outfits){o->val owned=o.name in vm.owned;Card(Modifier.fillMaxWidth().padding(vertical=6.dp),colors=CardDefaults.cardColors(containerColor=Card)){Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){Text(o.emoji,style=MaterialTheme.typography.headlineMedium);Column(Modifier.weight(1f).padding(horizontal=15.dp)){Text(o.name,fontWeight=FontWeight.Bold);Text(o.style,color=Muted);if(owned)Text("Owned",color=Green)};if(owned)Button(onClick={vm.wear(o.name)}){Text(if(vm.worn==o.name)"Worn" else "Wear")}else Button(onClick={ {vm.buy(o)} },enabled=vm.curo>=o.price){Text("🪙 ${o.price}")}}}}}}}

@Composable fun ExerciseDialog(e:Exercise,onClose:()->Unit,onComplete:()->Unit){AlertDialog(onDismissRequest=onClose,title={Text(e.name,fontWeight=FontWeight.Bold)},text={Column{Text("Body part: ${e.body}",color=Green);Text("Level: ${e.level}");Text("Target: ${e.sets} sets × ${e.reps}");Text("Reward: +${e.curo} CURO");Spacer(Modifier.height(12.dp));Text("How to do it",fontWeight=FontWeight.Bold);Text(e.how);Spacer(Modifier.height(10.dp));Text("Avoid",fontWeight=FontWeight.Bold);Text(e.avoid,color=Color(0xFFFFB4AB));Spacer(Modifier.height(10.dp));Text("Stop if you feel pain, dizziness, faintness, unusual shortness of breath, or feel unwell.",color=Color(0xFFFFD8D2))}},confirmButton={Button(onClick=onComplete,colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Color.Black)){Text("Mark complete")}},dismissButton={TextButton(onClick=onClose){Text("Cancel")}})}

fun main() {}
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}}
