# CuroFit
Gamified workout planner prototype built with Kotlin + Jetpack Compose.

Features: exercise library, body-part filters, sets/reps, exercise-specific CURO, 1000 CURO per 10-exercise level, optional routine, Indian/Western/Indo-Western cosmetic outfits, avatar shop, and safety guidance.

Open the CuroFit folder in Android Studio and run it.
